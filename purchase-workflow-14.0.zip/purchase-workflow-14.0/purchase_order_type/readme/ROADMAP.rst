* Suggestion: add a default configuration attached to the types
