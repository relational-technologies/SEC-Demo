This module adds a "Package quantity" field on purchase order line in order to
define a quantity according to the selected "Package".

Inspired from `sale_order_line_packaging_qty` module.
