* Create RFQ as normal
* As user click "Convert to Order", the isolated purchases order will be created
