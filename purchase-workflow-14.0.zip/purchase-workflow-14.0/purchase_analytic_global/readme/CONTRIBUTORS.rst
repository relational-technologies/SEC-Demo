* `Camptocamp <https://camptocamp.com>`_:
    * Guewen Baconnier <guewen.baconnier@camptocamp.com>
    * Yannick Vaucher <yannick.vaucher@camptocamp.com>
    * Iryna Vyshnevska <i.vyshnevska@camptocamp.com>
* `ERP Harbor <https://erpharbor.com>`_:
    * Sudhir Arya <sudhir@erpharbor.com>
* `Trobz <https://trobz.com>`_:
    * Phuc Tran <phuc@trobz.com>
