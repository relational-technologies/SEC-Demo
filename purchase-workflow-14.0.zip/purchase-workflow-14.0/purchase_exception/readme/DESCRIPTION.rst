This module allows you attach several customizable exceptions to your
purchase order in a way that you can filter orders by exceptions type and fix them.

This is especially useful in an scenario for mass purchases order import, because it's likely some orders have
errors when you import them (like product not found in Odoo, wrong line
format etc.)
