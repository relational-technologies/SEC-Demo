Integrated in the normal flow.
