This module propagates the description from the purchase order lines to the stock picking
