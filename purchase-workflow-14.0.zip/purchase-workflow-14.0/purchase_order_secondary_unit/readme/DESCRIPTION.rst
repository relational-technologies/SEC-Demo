This module extends the functionality of purchase orders to allow buy products
in secondary unit of distinct category.
