In the **Products** menu (or in the **Product Variants** menu), in the list view, select several products and click on **Action > Replenish**.
