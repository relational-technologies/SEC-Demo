This module adds a wizard on the **Products** tree view to replenish.

The official *stock* module adds a button
*Replenish* on the Product form view; this module does the
same thing in batch for several products at the same time.
