To use this module, the company have to access rights Multi Currencies.

Step to used manual currency:
#. Go to Invoicing > Configuration > Settings > Currencies > Multi-Currencies
#. Go to Purchase > Create new purchase.
#. Change to other currency (not main currency)
#. Check Manual Currency and specify your currency rate
