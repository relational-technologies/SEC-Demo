This module allows users to update the currency manual of Purchase Order in draft state.

Example, The company will make a deal with vendor before buy product
that process maybe not same day.
So, currency rate in purchase order will calculated from order date
but Company get currency rate from date of make a deal or special currency rate.
