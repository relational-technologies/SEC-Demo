After install this module, you need to select the product "Purchase Deposit" in
configuration window to be used as default product when create deposit bill.

Go to Purchase > Configuration > Settings, then select product "Purchase Deposit"

Note: If this is not done, by using "Register Deposit" for the first time will
also create product "Purchase Deposit" for you automatically.
