Add a button on product forms to access Purchase Lines
