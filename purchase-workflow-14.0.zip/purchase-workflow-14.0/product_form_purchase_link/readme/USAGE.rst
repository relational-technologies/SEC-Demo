Go to Purchases > Purchase > Products

Click on the button 'Purchases' with the list icon
