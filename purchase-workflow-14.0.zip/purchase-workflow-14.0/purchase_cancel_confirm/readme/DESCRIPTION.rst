When user click to cancel purchase order, a confirmation wizard will be show, with reason as optional.
