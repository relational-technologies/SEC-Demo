In the search view of RFQ/purchase orders, you can group by *Commercial Supplier*.
