#. Go to **Purchase > Settings > Default Sort Criteria** and select one.
#. You must select sort direction too.
#. Create a new purchase and add several lines.
#. On saving purchase order you must see how the purchase lines are ordered
   with your selected sort order.
