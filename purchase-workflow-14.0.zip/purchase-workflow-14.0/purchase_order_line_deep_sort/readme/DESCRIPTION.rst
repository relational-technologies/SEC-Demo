This module was written to extend the functionality of purchase order and allow
you to manage sort of lines.

You can set the default sort order for the current company or you can set sort
order for a particular purchase order.
