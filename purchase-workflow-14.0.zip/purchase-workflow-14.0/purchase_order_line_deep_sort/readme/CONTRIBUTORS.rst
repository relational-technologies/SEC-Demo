* `Tecnativa <https://www.tecnativa.com:>`_:

  * Vicent Cubells <vicent.cubells@tecnativa.com>
  * Pedro M. Baeza

* `Prothai <https://www.prothaitechnology.com:>`_:

    * Prapassorn Sornkaew <prapassorn.s@prothaitechnology.com> (migrate to v14)
