* Add support for ordering purchase lines by partner.
