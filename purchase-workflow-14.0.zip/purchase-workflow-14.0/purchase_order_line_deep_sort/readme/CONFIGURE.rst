* Sort criteria items can be defined with a dot notation. This means that you
  can define an order as follows: **product_id.default_code**. But the field
  defined must exist in database. If you define, e.g., a calculated field, sort
  criteria won't work.
