This module allows you to block the approval of an RFQ when an Approval
Block Reason has been provided. Upon confirmation of an RFQ the orders will be
waiting for approval by a Manager.
