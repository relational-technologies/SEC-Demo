* Go to ‘Purchases / Configuration / Purchase Approval Block Reasons’ and create
  the blocking reasons as needed, providing a name and a description. A field
  ‘Active’ allows you to deactivate the reason if you do not plan to use it
  any more.
* Assign the security group 'Release RFQ with approval block' to users that
  should be able to release the block. Users in group 'Purchase / Managers'
  are by default assigned to this group.
