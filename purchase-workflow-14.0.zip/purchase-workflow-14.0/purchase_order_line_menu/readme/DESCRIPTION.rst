Adds a menu item to list all Purchase Order lines.
