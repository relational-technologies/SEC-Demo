To use this module, you need to:

Go to the vendors form and clic on purchase order lines button.
Thereafter select lines you want to invoice and clic on Action/Create Invoice.
A wizard will open. Introduce the quantity to invoice for each lines and then
create the invoice.
