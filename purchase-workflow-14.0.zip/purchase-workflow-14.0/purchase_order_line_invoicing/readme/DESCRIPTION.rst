This module allows to invoice lines of multiple purchase orders from a single
 supplier.
