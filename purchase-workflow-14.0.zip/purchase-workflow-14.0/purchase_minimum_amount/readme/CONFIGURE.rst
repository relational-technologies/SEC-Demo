* Go to 'Purchases / Purchase / Vendors'
* Click on a Vendor and inside the 'Sales & Purchases' page specify the
  non-required field 'Minimum Purchase Amount'.
* Assign the security group 'Release RFQ with approval block' to users that
  should be able to release the block. Users in group 'Purchase / Managers'
  are by default assigned to this group.
