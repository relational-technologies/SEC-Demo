This module allows you to establish and automate a specific Purchase Order
Approval Block Reason in the system: the 'Minimum Purchase Order Amount per
Vendor'.
