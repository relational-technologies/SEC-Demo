#. Create a purchase order and confirm it.
#. Receive the products/services.
#. Create a vendor bill and reduce the invoiced quantity. The purchase order
   invoicing status is 'Waiting Bills'.
#. Lock the Purchase Order and change its status to 'Done'.
#. Check the field 'Force Invoiced'.
