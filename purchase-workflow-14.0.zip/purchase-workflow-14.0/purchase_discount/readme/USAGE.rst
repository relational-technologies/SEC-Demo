Go to **Purchase > Products**, open one product, and edit or add a record on
the **Vendors** section of the **Purchase** tab. You will see in the prices
section in the down part a new column called **Discount (%)**. You can enter
here the desired discount for that quantity.

When you make a purchase order for that supplier and that product, discount
will be put automatically.
