This module extends the functionality of Purchase to allow you to see the price
history of a product from a purchase order line and set one of these
old prices in the purchase order line.
