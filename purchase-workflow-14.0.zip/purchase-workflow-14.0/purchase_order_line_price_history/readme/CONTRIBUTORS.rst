* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda

* Dhiren Joshi <d.joshi.serpentcs@gmail.com>
