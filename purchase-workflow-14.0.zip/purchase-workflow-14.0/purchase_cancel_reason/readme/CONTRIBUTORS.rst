* Guewen Baconnier, Camptocamp SA
* Sylvain Van Hoof <sylvain@okia.be>

* `Ecosoft <http://ecosoft.co.th>`_:

  * Kitti U. <kittiu@ecosoft.co.th>
  * Tharathip C. <tharathipc@ecosoft.co.th>
