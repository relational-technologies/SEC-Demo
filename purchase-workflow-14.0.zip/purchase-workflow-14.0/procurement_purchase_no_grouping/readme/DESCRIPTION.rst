This module allows to not group generated purchase orders from procurements.
The grouping behaviour can be configurable at product category level or fall back
to system default.
