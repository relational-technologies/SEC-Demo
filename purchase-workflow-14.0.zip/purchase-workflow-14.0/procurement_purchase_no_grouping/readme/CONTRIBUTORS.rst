* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Sergio Teruel
  * Carlos Dauden
  * Alexandre Díaz
  * Víctor Martínez

* Ana Juaristi <ajuaristo@gmail.com>
* Alfredo de la Fuente <alfredodelafuente@avanzosc.es>
* Radovan Skolnik <radovan@skolnik.info>
