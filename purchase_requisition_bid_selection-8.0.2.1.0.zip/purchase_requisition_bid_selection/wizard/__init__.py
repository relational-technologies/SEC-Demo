# -*- coding: utf-8 -*-
from . import purchase_requisition_partner
from . import update_bid_internal_remark
from . import update_remark
