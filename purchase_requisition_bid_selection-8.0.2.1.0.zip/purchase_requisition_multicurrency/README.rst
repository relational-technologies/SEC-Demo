Purchase Requisition Multicurrency
==================================

This module improve advanced bid selection with use of multi-currency.

When entering in RFQ selection, in a Call for Bids, via "Choose product lines"
button, prices will be displayed in Call for Bids' currency.

Currency rate exchange can be freezed by setting Exchange Rate Date field on
Call for bids.

Contributors
------------

* Yannick Vaucher <yannick.vaucher@camptocamp.com>
